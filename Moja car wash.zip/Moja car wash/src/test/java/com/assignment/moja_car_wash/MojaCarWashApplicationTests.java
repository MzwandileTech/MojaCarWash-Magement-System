package com.assignment.moja_car_wash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MojaCarWashApplicationTests {

    @Test
    void contextLoads() {
    }

}
