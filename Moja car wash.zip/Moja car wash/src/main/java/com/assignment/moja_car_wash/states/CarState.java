package com.assignment.moja_car_wash.states;

public enum CarState {
    PRE_WASH,
    WASHING,
    COMPLETED
}
